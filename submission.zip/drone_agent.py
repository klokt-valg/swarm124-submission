from __future__ import annotations

from typing import Any, Dict

import numpy as np
from stable_baselines3 import PPO
import torch
import torch.nn as nn
import pybullet as p
from sklearn.cluster import DBSCAN
import cv2

CTRL_STEPS = 5

# =============================================================================
# SIMULATION & PHYSICS
# =============================================================================

# Core simulation parameters
SIM_DT = 1 / 50  # Physics simulation timestep (50 Hz)
HORIZON_SEC = 60  # Maximum simulated flight duration (seconds)
# Depth sensor parameters
DEPTH_NEAR = 0.05                       # PyBullet camera near plane (meters)
DEPTH_FAR = 1000.0                      # PyBullet camera far plane (meters)
DEPTH_MIN_M = 0.5                       # Minimum useful depth range (meters)
DEPTH_MAX_M = 20.0                      # Maximum useful depth range (meters)
# Search area parameters
SEARCH_RADIUS_MAX = 10.0             # ±10m horizontal noise = 20m total search zone
SEARCH_AREA_NOISE_Z = 2.0               # ±2m vertical noise

# =============================================================================
# DRONE & FLIGHT CONTROL
# =============================================================================

# Drone physical specifications
DRONE_MASS = 0.027  # Drone mass (kg) - CF2X Crazyflie
# DRONE_MASS = 0.9  # Drone mass (kg) - SwarmDrone Crazyflie
MAX_RAY_DISTANCE = 20.0  # Maximum obstacle detection range (meters)

# Landing and positioning parameters
LANDING_PLATFORM_RADIUS = 0.6  # Landing platform acceptance radius (meters)
HOVER_SEC = 0  # Required hover duration for mission success (seconds)
SPEED_LIMIT = 3.0  # Maximum drone velocity limit (m/s)
ANGLE_VEL_LIMIT = 10
SAFETY_DISTANCE_SAFE = 1.0              # Full safety score at this clearance (meters)
SAFETY_DISTANCE_DANGER = 0.2            # Zero safety score at this clearance (meters)

MAX_TILT_RAD = 1.047  # Maximum drone tilt (roll and pitch)
GRAVITY = 9.8

def compute_unit_vector(vec: np.ndarray):
    norm = np.linalg.norm(vec)
    if norm == 0:
        return np.zeros(vec.shape)
    else:
        return vec / norm

def limit_vector_scalar(vec: np.ndarray, scalar: float | int):
    norm = np.linalg.norm(vec)
    if norm > scalar:
        return vec / norm * scalar
    else:
        return vec

def get_rotation_matrix(rpy: np.ndarray):
    """
    Generates a 3D rotation matrix (Z-Y-X convention) from Euler angles.
    Angles must be in radians.
    """
    return np.array(p.getMatrixFromQuaternion(p.getQuaternionFromEuler(rpy))).reshape(3, 3)


def compute_matrices(drone_pos, drone_rpy,
                     camera_offset=0.13, camera_baseline=0.05,
                     fov=90, aspect=1.0, near=0.05, far=1000.0):
    # Convert RPY to a rotation matrix
    rot_mat = get_rotation_matrix(drone_rpy)

    # 1. Calculate the Forward Direction Vector
    # Local Forward in PyBullet drones is usually X-axis: [1, 0, 0]
    # If your model's 'front' is different, change this vector
    local_forward = np.array([1, 0, 0]) 
    world_forward = rot_mat @ local_forward

    # 2. Calculate the "Up" Vector (Local Z-axis: [0, 0, 1])
    local_up = np.array([0, 0, 1])
    world_up = rot_mat @ local_up

    # 3. Define the Target Point
    # The camera looks at a point 20 meter in front of the drone
    camera_pos = drone_pos + world_forward * camera_offset + world_up * camera_baseline

    target_pos = camera_pos + world_forward * 20.0

    # Generate View Matrix
    view_mat = p.computeViewMatrix(
        cameraEyePosition=camera_pos,
        cameraTargetPosition=target_pos,
        cameraUpVector=world_up
    )

    # Generate Projection Matrix
    proj_mat = p.computeProjectionMatrixFOV(
        fov=fov,
        aspect=aspect,
        nearVal=near,
        farVal=far
    )

    return rot_mat, view_mat, proj_mat, camera_pos


def rotate_vector(vector, angle_degrees):
    if angle_degrees == 0:
        return np.array(vector)

    # Convert angle to radians
    theta = np.radians(angle_degrees)

    # Define the 2D rotation matrix
    c, s = np.cos(theta), np.sin(theta)
    rotation_matrix = np.array([
        [c, -s],
        [s, c]
    ])

    # We only rotate the X and Y components
    xy_rotated = rotation_matrix @ vector[:2]

    # Return with the original Z component if it's a 3D vector
    if len(vector) == 3:
        return np.array([xy_rotated[0], xy_rotated[1], vector[2]])
    return xy_rotated


def project_world_to_pixel(point, view_mat, proj_mat, res):
    # Standard PyBullet projection logic
    view_mat = np.array(view_mat).reshape(4, 4).T
    proj_mat = np.array(proj_mat).reshape(4, 4).T

    homog_point = np.append(point, 1.0)
    clip_space = proj_mat @ (view_mat @ homog_point)

    if clip_space[3] <= 0:
        return None

    ndc = clip_space[:2] / clip_space[3]
    # Convert NDC (-1 to 1) to Pixels (0 to res)
    px = (ndc[0] + 1.0) * res / 2.0
    py = (1.0 - ndc[1]) * res / 2.0
    return [px, py]


def get_wrapper_rect(points):
    xmin, ymin = np.min(points, axis=0)
    xmax, ymax = np.max(points, axis=0)
    rect = (int(xmin), int(ymin), int(xmax), int(ymax))
    return rect



class DroneWorldTransformer:
    def __init__(self, fov_deg=90, resolution=128, baseline=0.05):
        self.N = resolution
        self.fov_rad = np.radians(fov_deg)
        self.f_px = (self.N / 2.0) / np.tan(self.fov_rad / 2.0)
        self.baseline = baseline

    def set_drone_stance(self, drone_pos, drone_rpy):
        self.drone_pos = drone_pos
        self.drone_rpy = drone_rpy
        # Compute matrices
        rot_matrix, view_matrix, proj_matrix, camera_pos = compute_matrices(drone_pos, drone_rpy)
        self.rot_mat = rot_matrix
        self.camera_pos = camera_pos
        view_mat = np.array(view_matrix).reshape(4, 4).T
        proj_mat = np.array(proj_matrix).reshape(4, 4).T
        self.inv_view_mat = np.linalg.inv(view_mat)
        self.inv_proj_mat = np.linalg.inv(proj_mat)
        self.inv_vp_mat = self.inv_view_mat @ self.inv_proj_mat

    def unproject_ndc_to_world(self, ndc_point):
        # NDC -> View Space
        view_point = self.inv_proj_mat @ ndc_point
        view_point /= view_point[3]  # Perspective divide
        # View Space -> World Space
        world_point = self.inv_view_mat @ view_point
        return world_point[:3]

    def compute_camera_error(self, pixel_ray_meters: float) -> np.ndarray:
        # delta_z = (pixel_ray_meters**2 / (self.f_px * self.baseline)) * 0.5
        delta_z = (pixel_ray_meters**2 / (self.f_px * 20)) * 0.5
        delta_lat = (0.5 * pixel_ray_meters) / self.f_px
        delta = np.array([delta_lat, delta_lat, delta_z]).flatten()
        delta = self.rot_mat @ delta
        return delta

    @property
    def camera_intrinsic_matrix(self) -> np.ndarray:
        # Calculate focal length (assuming square pixels, so fx = fy)
        # Use width for horizontal FOV
        fx = fy = self.f_px

        # Principal point (center of the 32x32 image)
        cx = cy = self.N / 2       
        K = np.array([
            [fx, 0, cx],
            [0, fy, cy],
            [0, 0, 1]
        ], dtype=np.float32)

        return K

    def convert_obs_to_world(self, depth_norm: np.ndarray) -> np.ndarray:
        depth_metre = depth_norm * (DEPTH_MAX_M - DEPTH_MIN_M) + DEPTH_MIN_M  # now meter depth map

        # 1. Create a grid of NDC coordinates (x, y from -1 to 1)
        h, w = depth_metre.shape
        y, x = np.mgrid[0:h, 0:w]

        # Normalize x, y to [-1, 1] range
        ndc_x = (x / (w - 1)) * 2 - 1
        ndc_y = (1 - (y / (h - 1))) * 2 - 1  # Inverted because image Y is top-down

        # 2. Create Homogeneous coordinates (N, 4)
        # ndc_points shape: (4, H*W)
        ndc_points = np.stack([ndc_x.ravel(), ndc_y.ravel(), np.ones(h * w), np.ones(h * w)])

        # 3. Apply the pre-calculated combined matrix
        raw_directions = self.inv_vp_mat @ ndc_points
        raw_directions = raw_directions[:3, :] / raw_directions[3, :]

        # 4. Calculate Unit Vectors (Normalize each column)
        # L2 Norm along axis 0 (the x,y,z components)
        norms = np.linalg.norm(raw_directions, axis=0)

        # Avoid division by zero for any invalid points
        norms[norms == 0] = 1.0 
        unit_vectors = raw_directions / norms

        # 5. Apply the Meter Depth scaling
        # We reshape the meter map to (1, H*W) to multiply across the (3, H*W) points
        meter_depth_flat = depth_metre.ravel()
        world_points = unit_vectors * meter_depth_flat
        world_points_final = world_points.T.reshape(h, w, 3) + self.camera_pos

        # 7. Reshape to (H, W, 3)
        return world_points_final

    def convert_obs_to_world_pt(self, px: float, py: float, pixel_depth: float) -> np.ndarray:
        # lets convert px, py into world coordinate
        pixel_ray_meters = pixel_depth * (DEPTH_MAX_M - DEPTH_MIN_M) + DEPTH_MIN_M
        # 1. Convert pixel to Normalized Device Coordinates (NDC)
        # Range: [-1, 1], where -1 is left/bottom and 1 is right/top
        ndc_x = (2.0 * px / (self.N - 1)) - 1.0
        ndc_y = (1.0 - py / (self.N - 1)) * 2.0 - 1.0  # Y is flipped in screen space
        # 2. Create a point in Clip Space
        # We use z=1.0 (far plane) to define the direction
        ndc_point = np.array([ndc_x, ndc_y, 1.0, 1.0])
        ray_world = self.unproject_ndc_to_world(ndc_point)
        ray_world_unit = compute_unit_vector(ray_world)
        world_pos = ray_world_unit * pixel_ray_meters + self.camera_pos
        return world_pos

    def convert_world_pt_to_obs(self, world_point: np.ndarray) -> np.ndarray:
        """
        world_point: np.array([x, y, z])
        drone_pos: np.array([x, y, z])
        drone_quat: np.array([w, x, y, z])
        intrinsic_matrix: 3x3 K matrix
        """
        # 1. World to Camera Transformation
        # (Using a helper to get the rotation matrix from quaternion)
        R = self.rot_mat

        # Relative position
        rel_pos = world_point - self.drone_pos

        # Point in camera frame: X_c = R_inv * (X_w - t)
        # R.T is the inverse for rotation matrices
        point_cam = R.T @ rel_pos

        # 2. Project to 2D
        # Check if point is behind camera
        if point_cam[2] <= 0:
            return None  # Object is behind the drone

        # 3. Apply Intrinsic Matrix
        point_img_homo = self.camera_intrinsic_matrix @ point_cam
        u = point_img_homo[0] / point_img_homo[2]
        v = point_img_homo[1] / point_img_homo[2]

        return np.array([u, v])

    def get_voxel_points(self, world_pos: np.ndarray, delta: np.ndarray, mode='center'):
        center = world_pos + delta * 0.5
        if mode == 'box':
            return [
                world_pos,
                world_pos + np.array([0, 0, delta[2]]),
                world_pos + np.array([0, delta[1], 0]),
                world_pos + np.array([0, delta[1], delta[2]]),
                world_pos + np.array([delta[0], 0, 0]),
                world_pos + np.array([delta[0], 0, delta[2]]),
                world_pos + np.array([delta[0], delta[1], 0]),
                world_pos + np.array([delta[0], delta[1], delta[2]]),
                center,
            ]
        else:
            return [world_pos, center]


class ObservationData:
    """Decomposes Observation Data"""

    def __init__(self, observation: Dict, transformer: DroneWorldTransformer, image_size=128):
        self.N = image_size
        self.transformer = transformer
        self.depth = observation["depth"]  # Original Shape (H, W, 1)
        obs_state = observation["state"]
        self.pos = obs_state[0:3]
        self.rpy = obs_state[3:6]
        self.vel = obs_state[6:9]
        self.ang_vel = obs_state[9:12]
        self.alt = obs_state[-4] * MAX_RAY_DISTANCE
        self.goal_vec = obs_state[-3:]
        self.world_pos_map = None

    @property
    def depth_norm(self):
        return np.squeeze(self.depth, axis=2)

    @property
    def res(self):
        return 128

    @property
    def search_center(self):
        return self.goal_vec + self.pos

    @property
    def yaw(self):
        return self.rpy[2]

    @property
    def roll(self):
        return self.rpy[0]

    @property
    def pitch(self):
        return self.rpy[1]

    @property
    def goal_max_alt(self):
        return self.pos[2] + self.goal_vec[2] + SEARCH_AREA_NOISE_Z

    @property
    def speed(self):
        return np.linalg.norm(self.vel)

    @property
    def speed_horiz(self):
        return np.linalg.norm(self.vel[0:2])

    def vis_pt_world_pos(self, px: int, py: int) -> np.ndarray:
        """World position of a pixel in the current vision
        """
        if self.world_pos_map is None:
            self.world_pos_map = [[None for _ in range(self.transformer.N)] for _ in range(self.transformer.N)] 

        p = self.world_pos_map[py][px]
        if p is None:
            p = self.transformer.convert_obs_to_world_pt(px, py, self.depth[py, px])
            self.world_pos_map[py][px] = p
        return p

    def vis_to_world(self) -> np.ndarray:
        """World position of a pixel in the current vision
        """
        if self.world_pos_map is not None:
            return self.world_pos_map
        self.world_pos_map = self.transformer.convert_obs_to_world(self.depth_norm)
        # uv = [(0, 0), (48, 48), (95, 95)]
        # for u, v in uv:
        #     print(f"({u}, {v}) -> {self.world_pos_map[u, v]}")
        # print("\n")

        # ensure z-axis value is >=0
        mask = self.world_pos_map[:, :, 2] < 0
        self.world_pos_map[mask] = 0
        return self.world_pos_map

    @property
    def forward_vec(self) -> np.ndarray:
        R = get_rotation_matrix(self.rpy)
        return R @ np.array([1, 0, 0])

    def mask_detect_box(self, detect_box):
        px, py, w, h, conf = detect_box
        if conf >= 0.5 and w > 0 and h > 0:
            # If detected landing platform from neural network        
            x1, y1 = int(px - w / 2), int(py - h / 2)
            x2, y2 = int(x1 + w), int(y1 + h)
            x1, y1 = max(x1, 0), max(y1, 0)
            x2, y2 = min(self.N, max(x2 + 1, 0)), min(self.N, max(y2 + 1, 0))
            self.depth[y1:y2, x1:x2] = 1


class DroneAgentMixin:
    def _draw_debug(self, obs: ObservationData,
                    flight_dir: np.ndarray = None):
        if self.env is None or not self.env.GUI:
            return

        client_id = self.env.CLIENT

        def __draw_ray(angle_rad, ray_len, color=None, ttl=SIM_DT * 10):
            cos_a = np.cos(angle_rad)
            sin_a = np.sin(angle_rad)
            p.addUserDebugLine(
                lineFromXYZ=obs.pos,
                lineToXYZ=obs.pos + np.array([cos_a, sin_a, 0]) * ray_len,
                lineColorRGB=[0, cos_a, sin_a] if color is None else color,
                lifeTime=ttl,
                physicsClientId=client_id,
            )
        # flight trail (blue)
        __draw_ray(obs.yaw, 0.2, color=(0, 0, 1), ttl=0)

        # Current yaw line (Black)
        __draw_ray(obs.yaw, 3)

        if flight_dir is not None:
            # Milestone line (Red)
            milestone_angle_rad = np.arctan2(flight_dir[1], flight_dir[0])      
            __draw_ray(milestone_angle_rad, np.linalg.norm(flight_dir), color=(1, 0, 0))

    def _debug_drone_sight(self, obs: ObservationData, detect_box: np.ndarray = None):
        if self.env is None:
            return

        if not getattr(self.env, "debug_drone_sight", False):
            return

        # ----------------------------
        # Retrieves and displays Depth buffers side-by-side.
        # ----------------------------

        # Process Depth (H, W) -> Normalize depth map to 0-255 for visualization
        depth_viz = (obs.depth * 255).astype(np.uint8)
        depth_viz_bgr = cv2.cvtColor(depth_viz, cv2.COLOR_GRAY2BGR)

        # Draw detect box
        if detect_box is not None:
            cx, cy, w, h, conf = detect_box
            if conf >= 0.5:
                x1, y1 = int(cx - w / 2), int(cy - h / 2)
                x2, y2 = int(x1 + w), int(y1 + h)
                cv2.rectangle(depth_viz_bgr, (x1, y1), (x2, y2), color=(0,0,255), thickness=2)
                cv2.putText(depth_viz_bgr, f"{conf:.02f}", (10, 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), thickness=1)

        # Combine and Display
        combined = np.hstack((depth_viz_bgr,))
        cv2.imshow("Drone Camera: Depth", combined)
        cv2.waitKey(1)


class LandingDetector(nn.Module):
    """Landing Platform Detector network
    """

    def __init__(self):
        super(LandingDetector, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=3, padding=1), nn.ReLU(),
            nn.MaxPool2d(2),  # 64x64
            nn.Conv2d(16, 32, kernel_size=3, padding=1), nn.ReLU(),
            nn.MaxPool2d(2),  # 32x32
            nn.Conv2d(32, 64, kernel_size=3, padding=1), nn.ReLU(),
            nn.MaxPool2d(2),  # 16x16
            nn.Conv2d(64, 128, kernel_size=3, padding=1), nn.ReLU(),
            nn.MaxPool2d(2)  # 8x8
        )
        self.detector = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128 * 8 * 8, 256),
            nn.ReLU(),
            nn.Dropout(0.2),  # Prevents overfitting
            nn.Linear(256, 5)  # [x, y, w, h, confidence]
        )

    def forward(self, x):
        x = self.features(x)
        return self.detector(x)


class DroneLandingPadTracker:
    DETECT_CRITERIA = 0.2

    def __init__(self, model_path: str,
                 mapper: DroneWorldMapper,
                 transformer: DroneWorldTransformer,
                 resolution=128,
                 dt=SIM_DT):
        self.mapper = mapper
        self.transformer = transformer
        self.N = resolution
        self.dt = dt

        self.last_known_pos = None
        self.last_sensor_pos = None

        # initialize model
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = LandingDetector().to(self.device)
        self.model.load_state_dict(torch.load(model_path))
        self.model.eval()

        self.reset()

    def reset(self):
        # Initialize Kalman Filter (State: [x, y, z, vx, vy, vz])
        print(f"Reset Landing Site Tracker!")
        dt = self.dt
        self.smooth_confidence = 0
        self.blacklist = []
        self.kf = cv2.KalmanFilter(6, 3)
        self.kf.transitionMatrix = np.array([[1, 0, 0, dt, 0, 0],
                              [0, 1, 0, 0, dt, 0],
                              [0, 0, 1, 0, 0, dt],
                              [0, 0, 0, 1, 0, 0],
                              [0, 0, 0, 0, 1, 0],
                              [0, 0, 0, 0, 0, 1]], dtype=np.float32)
        self.kf.measurementMatrix = np.array([[1, 0, 0, 0, 0, 0],
                              [0, 1, 0, 0, 0, 0],
                              [0, 0, 1, 0, 0, 0]], dtype=np.float32)
        self.kf.errorCovPost *= 10.0  # Initial uncertainty
        self.kf.processNoiseCov *= 0.05  # Process noise (how much the obstacle might change its own speed)
        self.conf_alt = None  # Real altitude of the pad, confirmed with observation
        self.conf_pt = None

    def is_in_blacklist(self, pos, perimeter=3):
        # check 2. start platform and end platform look similar, so distinguish them
        if np.linalg.norm(pos - self.mapper.start_pos) <= perimeter:
            return True

        for bpos in self.blacklist:
            l = bpos.shape[0]
            if np.linalg.norm(pos[:l] - bpos) <= perimeter:
                return True
        return False

    def process_frame(self, obs: ObservationData, step: int = 0):
        self.search_center = obs.search_center

        # In your simulation loop:
        with torch.no_grad():
            # merge depth to form input
            depth_tensor = torch.from_numpy(obs.depth[:, :, :]).permute(2, 0, 1).float().unsqueeze(0)
            prediction = self.model(depth_tensor.to(self.device))
            cx, cy, w, h, conf = prediction[0].cpu().numpy()
            # Scale back to pixels for visualization
            px, py = int(abs(cx) * self.N), int(abs(cy) * self.N)
            w, h = int(abs(w) * self.N), int(abs(h) * self.N)
            conf = np.clip(conf, 0, 1)
            detect_box = np.array([px, py, w, h, conf])

        candidates = []
        if conf >= 0.5 and w > 0 and h > 0:
            # If detected landing platform from neural network        
            x1, y1 = int(px - w / 2), int(py - h / 2)
            x2, y2 = int(x1 + w), int(y1 + h)
            x1, y1 = max(x1, 0), max(y1, 0)
            x2, y2 = min(self.N, max(x2 + 1, 0)), min(self.N, max(y2 + 1, 0))

            for px in range(x1, x2):
                for py in range(y1, y2):
                    # skip pixels that are far away
                    if obs.depth[py, px] >= 0.95:
                        continue

                    pt = obs.vis_pt_world_pos(px, py)

                    # Check if the detected box really contains end platform
                    # check 1. end platform must be in search area
                    if not self.mapper.point_in_search_area(pt):
                        continue

                    # check 2. start platform and end platform look similar, so distinguish them
                    if self.is_in_blacklist(pt):
                        continue

                    candidates.append(pt)

        if not self.update_with_points(np.array(candidates), obs.pos, conf):
            detect_box[4] = 0

        pos, vel = self.prediction           
        return detect_box, pos, vel

    @property
    def confidence(self):
        return self.smooth_confidence

    @property
    def detected(self):
        return self.smooth_confidence > self.DETECT_CRITERIA

    @property
    def confirmed(self):
        return self.conf_alt is not None

    @property
    def pos(self):
        pos_est = self.prediction[0]
        if pos_est is not None:
            if self.conf_alt is not None:
                pos_est[2] = self.conf_alt
            else:
                pos_est[0] = np.clip(pos_est[0], self.search_center[0] - SEARCH_RADIUS_MAX, self.search_center[0] + SEARCH_RADIUS_MAX)
                pos_est[1] = np.clip(pos_est[1], self.search_center[1] - SEARCH_RADIUS_MAX, self.search_center[1] + SEARCH_RADIUS_MAX)
                pos_est[2] = np.clip(pos_est[2], self.search_center[2] - SEARCH_AREA_NOISE_Z, self.search_center[2] + SEARCH_AREA_NOISE_Z)
        return pos_est

    @property
    def vel(self):
        return self.prediction[1]

    @property
    def prediction(self):
        if self.detected:
            state = self.kf.statePost[:6].flatten()
            return state[:3], state[3:6]  # Pos and Velocity
        else:
            return None, None

    def _update_confidence(self, hit: bool, conf=0):
        if hit:
            alpha = 0.1
            self.smooth_confidence = (alpha * conf) + (1 - alpha) * self.smooth_confidence
        else:
            # self.kf.predict()
            # Gradually decay confidence while missing
            self.smooth_confidence *= 0.99
        return hit

    def update_with_points(self, point_cloud, sensor_pos, conf=1.0):
        if len(point_cloud) == 0:
            return self._update_confidence(False)

        min_samples = 3

        # 2. Gating (Filter points too far from the Kalman prediction)
        if self.detected:
            predicted_pos, _ = self.prediction
            # Only keep points within 1.5 meters of where we THINK the platform is
            distances = np.linalg.norm(point_cloud - predicted_pos, axis=1)
            valid_points = point_cloud[distances < 1.5]
        else:
            valid_points = point_cloud

        if len(valid_points) < min_samples:
            # if point cloud is invalidated repeatedly, that might mean that the current
            # Kalman prediction is too off, and need re-do.
            return self._update_confidence(False)

        # eps: Max distance between two points to be in the same pad (e.g., 0.5m)
        # min_samples: Min points to consider it a real "object" and not a glitch
        clustering = DBSCAN(eps=LANDING_PLATFORM_RADIUS * 2, min_samples=min_samples).fit(valid_points)

        min_std = float('inf')
        best_center = None
        for label in set(clustering.labels_):
            if label == -1:
                continue  # Skip noise

            # Get all points in this specific cluster
            cluster_points = valid_points[clustering.labels_ == label]

            # landing pad is flat cylinder
            z_vals = cluster_points[:, 2]
            if z_vals.max() - z_vals.min() > 1.0:
                print(f"Too thick to be a landing pad: highest={z_vals.max()}, lowest={z_vals.min()}")
                continue

            # Calculate the centroid (the point the drone will actually fly to)
            std_dev = np.mean(np.std(cluster_points, axis=0))
            if std_dev < min_std:
                min_std = std_dev
                best_center = np.mean(cluster_points, axis=0)

        if best_center is None:
            return self._update_confidence(False)

        self.kf.predict()

        # 1. Dynamic R-Matrix Scaling
        # If confidence is low, we increase Measurement Noise (R).
        # This makes the filter ignore 'jittery' low-confidence boxes.
        confidence_weight = 1.0 / (conf + 1e-6)
        self.kf.measurementNoiseCov = np.eye(3, dtype=np.float32) * confidence_weight
        self.kf.correct(best_center.astype(np.float32))

        # 3. Confidence Smoothing (EMA)
        self._update_confidence(True, conf)

        if self.smooth_confidence > self.DETECT_CRITERIA:
            self.last_known_pos = self.pos
            self.last_sensor_pos = sensor_pos

        if self.smooth_confidence > 0.8:
            self.conf_pt = self.pos
            self.conf_alt = self.pos[2]

        return True

    def confirm_with_obs(self, obs: ObservationData):
        return True

class DroneWorldMapper:
    def __init__(self):
        self.res = 2
        self.reset()

    def reset(self):
        self.search_area_center = None
        self.start_pos = None

    def start(self, search_area_center: np.ndarray, start_pos: np.ndarray):
        self.search_area_center = search_area_center
        self.start_pos = start_pos
        min_pt, max_pt = self.get_search_area_bbx()
        self.explored = set()
        self.unknown = set()
        for i in range(int(SEARCH_RADIUS_MAX)):
            for j in range(int(SEARCH_RADIUS_MAX)):
                for k in range(int(SEARCH_AREA_NOISE_Z)):
                    self.unknown.add((i, j, k))
            
        self.min_pt = min_pt
        self.max_pt = max_pt

    def get_search_area_bbx(self):
        half_dims = np.array([
            SEARCH_RADIUS_MAX,
            SEARCH_RADIUS_MAX,
            SEARCH_AREA_NOISE_Z,
        ])
        min_pt = np.array(self.search_area_center - half_dims, dtype=np.float64)
        min_pt[2] = max(min_pt[2], 0)
        max_pt = np.array(self.search_area_center + half_dims, dtype=np.float64)
        
        return min_pt, max_pt

    def get_best_frontier(self, current_pos, z=None):
        """Clusters frontiers and ranks them by (Size / Distance)."""
        points = np.array(list(self.unknown), dtype=np.byte)

        # 1. Cluster points to find distinct 'rooms' or 'hallways'
        clustering = DBSCAN(eps=1, min_samples=3).fit(points)
        labels = clustering.labels_
        print(f"Point cloud tree is clustered into {len(set(labels))} clusters")

        ideal_dist = 4
        sensitivity = 10
        best_score = -np.inf
        best_goal = None

        for label in set(labels):
            if label == -1:
                continue  # Noise

            cluster_points = points[labels == label]
            centroid = self.min_pt + np.mean(cluster_points, axis=0) * self.res
            dist = np.linalg.norm(current_pos - centroid)

            # Score = Information Gain (cluster size) / Cost (dist)
            base_score = len(cluster_points) if dist > 2 else len(cluster_points) * 0.1
            exponent = -((dist - ideal_dist) ** 2) / (2 * (sensitivity ** 2))
            multiplier = np.exp(exponent)

            score = round(base_score * multiplier, 2)

            print(f"Label {label}: {len(cluster_points)} points, {dist:.02f}m away, scored {score:.02f}")
            if score > best_score or (score == best_score and best_dist < dist):
                best_goal = centroid
                best_score = score
                best_dist = dist

        if best_goal is None:
            cluster_points = points[labels == -1]
            if len(cluster_points) > 0:
                print(f"Label {-1}: {len(cluster_points)} points")           
                best_goal = self.min_pt + np.mean(cluster_points, axis=0) * self.res

        if best_goal is not None:
            if z is not None:
                return np.array([best_goal[0], best_goal[1], z])
            else:
                return best_goal
        else:
            return None

    def insert_point_cloud(self, point_cloud: list | np.ndarray, sensor_origin: np.ndarray, max_range=20):
        sensor_origin = sensor_origin.astype(np.float64)
        # this doesn't fill the ray path as unoccupied       
        for p in point_cloud:
            pvec = p - sensor_origin
            l = np.ceil(np.linalg.norm(pvec))
            for i in range(1, int(l) + 1, self.res):
                p1 = sensor_origin + pvec * (i / l)
                if self.point_in_search_area(p1):
                    idx = ((p1 - self.min_pt) // self.res).astype(np.byte)
                    idx = tuple(idx)
                    if idx in self.unknown:
                        self.unknown.remove(idx)
                        self.explored.add(idx)

    def point_in_search_area(self, position: np.ndarray):
        diff = np.abs(self.search_area_center - position)

        return (diff[0] < SEARCH_RADIUS_MAX
                and diff[1] < SEARCH_RADIUS_MAX
                and diff[2] < SEARCH_AREA_NOISE_Z)


class AeroInertiaGovernor:
    def __init__(self, max_tilt_rad=MAX_TILT_RAD,
                 max_speed_limit=SPEED_LIMIT,
                 dt=SIM_DT,
                 g=GRAVITY,
                 drone_mass=DRONE_MASS):
        self.dt = dt
        self.g = g
        # Physical Parameters
        self.m_d = 1.0 * drone_mass
        self.m_total = self.m_d
        # Environment & Power Constraints
        self.max_tilt_rad = max_tilt_rad
        self.f_hover_base = self.m_d * self.g
        self.f_max_engine = self.m_d * self.g * 2.25  # Max physical capability
        self.max_speed = max_speed_limit
        self.available_range = self.f_max_engine - self.f_hover_base

    def get_next_command(self, desired_dir: np.ndarray,
                         obs: ObservationData,
                         v_wind: np.ndarray,
                         desired_max_speed=None):
        """
        Computes the target velocity and the resulting 5D control vector.
        """
        flight_distance = np.linalg.norm(desired_dir)
        if flight_distance > 0:
            desired_dir_unit = desired_dir / flight_distance
        else:
            desired_dir_unit = np.array([0, 0, 1])
        # horizontal velocity vs vertical velocity rate
        vert_dir_rate = np.arctan2(desired_dir_unit[2], np.linalg.norm(desired_dir_unit[0:2]))
        if desired_max_speed is None:
            desired_max_speed = max(
                self.max_speed * min(1.0, flight_distance / MAX_RAY_DISTANCE),
                self.max_speed * max(np.cos(vert_dir_rate), 0.1)
            )

        # 3. Momentum-Preserving Direction

        # 4. Target Velocity with Wind Compensation
        # We "crab" into the wind to maintain the blended path
        target_v = (desired_dir_unit * desired_max_speed) - v_wind
        # 5. Thrust & Power Mapping
        # F_req = mass * accel - F_external
        dv_dt = (target_v - obs.vel) / self.dt

        # F_total = F_accel - F_aero + F_gravity
        f_horizontal = self.m_total * dv_dt[:2]
        f_vertical = self.m_total * (dv_dt[2] + self.g)

        # 5. Apply Maximum Tilt Constraint
        # The tilt angle is determined by the ratio of horizontal to vertical force
        if np.dot(compute_unit_vector(dv_dt[:2]), compute_unit_vector(obs.vel[:2])) < -0.95:
            # target horizontal velocity is near negative of current velocity
            # add braking force
            f_horizontal = f_horizontal - obs.vel[:2] * 0.8
            cur_tilt = 0
        else:
            cur_tilt = np.max(np.abs(obs.rpy[0:2]))

        f_horiz_mag = np.linalg.norm(f_horizontal)
        max_f_horiz = f_vertical * (np.tan(self.max_tilt_rad - cur_tilt))

        # 4. Subtract the "Angular Penalty"
        # We must subtract the centrifugal force already pulling the drone sideways
        f_horiz_available = max(0, max_f_horiz)
        if f_horiz_mag > f_horiz_available:
            # Scale down horizontal force to respect the tilt limit
            # This prevents the drone from "flipping" while trying to accelerate
            f_horizontal = f_horizontal * (f_horiz_available / f_horiz_mag)

        # Reconstruct final force vector
        f_final = np.array([f_horizontal[0], f_horizontal[1], f_vertical])

        # 6. Directional Unit Vector (3D)
        f_velocity = np.array([f_final[0], f_final[1], f_final[2] - self.m_total * self.g])
        # target_v = obs.vel + f_velocity / self.m_total * self.dt
        target_v = obs.vel + f_velocity / self.m_total * self.dt

        v_unit = compute_unit_vector(target_v)
        return {
            "v_unit": v_unit,
            "target_velocity": target_v,
        }


class FlightNavigationAgent:
    SEARCH_SPEED = SPEED_LIMIT * 0.5
    LAND_SPEED = 0.5

    def __init__(self, mapper: DroneWorldMapper,
                 tracker: DroneLandingPadTracker):
        self.mapper = mapper
        self.tracker = tracker
        self.reset()

    def reset(self):
        self._search_center_radius = 1.0
        self.step = 0
        self.state = "GROUND"

    def set_new_mission(self, drone_pos, mission_pos=None, perim=1.0, timeout=None):
        if mission_pos is None:
            mission_pos = np.array(self.mapper.search_area_center)
            perim = (SEARCH_RADIUS_MAX * self._search_center_radius, SEARCH_RADIUS_MAX * self._search_center_radius, SEARCH_AREA_NOISE_Z)
            self._search_center_radius *= 0.5
        if timeout is None:
            timeout_steps = int(np.linalg.norm(mission_pos - drone_pos) / self.SEARCH_SPEED * 50 * 2)
        else:
            timeout_steps = timeout * 50
        self.curr_mission_pos = mission_pos
        self.curr_mission_perim = perim
        self.curr_mission_timeout = self.step + timeout_steps
        print(f"Step {self.step}: New flight mission {self.curr_mission_pos}"
              f", distance={np.linalg.norm(self.curr_mission_pos - drone_pos)}"
              f", perim={self.curr_mission_perim}"
              f", timeout={self.curr_mission_timeout}")

    def start(self, obs: ObservationData):
        self.state = "FLY_TO_SR"
        self.start_pos = np.array(obs.pos)
        
        # set initial mission
        mission = np.zeros(3)
        mission[:2] = self.start_pos[:2] + compute_unit_vector(obs.goal_vec[:2]) * 3
        mission[2] = self.start_pos[2] + 0.1
        self.set_new_mission(obs.pos, mission, 2.5, timeout=2.0)
        print(f"Navigation agent is started...")

    def check_mission(self, drone_pos):
        vec = self.curr_mission_pos - drone_pos
        if self.step > self.curr_mission_timeout:
            print("Mission time out")
            return vec, True

        if isinstance(self.curr_mission_perim, (np.ndarray, list, tuple)):
            return vec, (abs(vec[0]) <= self.curr_mission_perim[0]
                         and abs(vec[1]) <= self.curr_mission_perim[1]
                         and abs(vec[2]) <= self.curr_mission_perim[2])
        else:
            dist = np.linalg.norm(vec)
            if dist <= self.curr_mission_perim:
                return vec, True
        return vec, False

    def set_state(self, state: str):
        if state != self.state:
            print(
                f"-------------------------------------------------------------------\n"
                f"Step {self.step}: Flight stage changed from {self.state} to {state}\n"
                f"-------------------------------------------------------------------\n")
            self.state = state

    def needs_vis_agent(self, obs: ObservationData):
        return self.state in ["SEARCH", "APPROACH_PAD"]

    def get_next_target(self, obs: ObservationData, detect_box: np.ndarray, step: int, vis_obs: ObservationData):
        """
        returns: velocity_vector (x, y, z)
        """
        self.step = step       
        max_speed = self.SEARCH_SPEED
        v_mission = None
        v_final = None
        yaw = obs.yaw

        if self.state in ["FLY_TO_SR", "SEARCH"]:
            v_mission, done = self.check_mission(obs.pos)
            if done:
                if self.state == "FLY_TO_SR":
                    self.set_state("SEARCH")

                frontier = self.mapper.get_best_frontier(obs.pos)
                if frontier is None:
                    self.set_new_mission(obs.pos, mission_pos=None)
                else:
                    self.set_new_mission(obs.pos, frontier, min(np.linalg.norm(obs.pos - frontier) / 2, self.mapper.res))
                v_mission, done = self.check_mission(obs.pos)

        if self.tracker.detected:
            pad_vec = self.tracker.pos - obs.pos
            dist_xy = np.linalg.norm(pad_vec[:2])
            v_mission = pad_vec
            yaw = np.arctan2(pad_vec[1], pad_vec[0])

            if self.state in ["FLY_TO_SR", "SEARCH"]:
                self.set_state("APPROACH_PAD")

            if abs(obs.yaw - yaw) > 0.1:
                # align yaw first
                v_final = np.array([0, 0, v_mission[2]])
            elif dist_xy <= LANDING_PLATFORM_RADIUS:
                # Logic: If radar shows a sudden height change, we are over the pad
                v_final = compute_unit_vector(v_mission) * 1.0 + self.tracker.vel * 1.0
                v_final[2] = -0.5
                max_speed = 2
                print(f"Step: {self.step}. Descending. Distance: {dist_xy}, Altitude: {obs.alt}")
            elif dist_xy < LANDING_PLATFORM_RADIUS * 5 and v_final is None:
                # if we are close enough to the pad, we can assume there is no obstacles in the path
                v_final = compute_unit_vector(v_mission) * 1.0 + self.tracker.vel * 1.2
                v_final[2] = np.sign(v_final[2]) * 0.5 if obs.alt >= 0.5 else 0.5
                max_speed = 2.5
                print(f"Step: {self.step}. Approaching. Distance: {dist_xy}, Altitude: {obs.alt}")

        elif v_mission is None:
            max_speed = self.SEARCH_SPEED
            self.set_state("SEARCH")
            self.set_new_mission(obs.pos, self.tracker.last_sensor_pos)
            v_mission = self.tracker.last_sensor_pos - obs.pos
            yaw = np.arctan2(v_mission[1], v_mission[0])

        # 3. FINAL VECTOR BLENDING
        if v_final is None:
            v_final = self.select_best_direction(v_mission, obs if vis_obs is None else vis_obs)

        # clip final velocity to safe range
        if np.linalg.norm(v_final) > max_speed:
            v_final = compute_unit_vector(v_final) * max_speed
            
        if np.linalg.norm(v_final[:2]) > 0.01:
            yaw = np.arctan2(v_final[1], v_final[0])
        elif np.linalg.norm(v_mission[:2]) > 0.01:
            yaw = np.arctan2(v_mission[1], v_mission[0])           
       
        return v_final, yaw

    def select_best_direction(self, v_mission, obs: ObservationData):
        speed = obs.speed_horiz
        look_ahead_dist = max(speed * 2.5, 4)
        safe_depth = (look_ahead_dist - DEPTH_MIN_M) / (DEPTH_MAX_M - DEPTH_MIN_M)
        best_v = None
        max_ray = 19
        max_range = min(np.linalg.norm(v_mission), max_ray)

        block = obs.res / 5
        score_grid = np.full((5, 5), -np.inf)
        point_vec_data = [[None for _ in range(5)] for _ in range(5)] 

        for (v, u), d in np.ndenumerate(score_grid):
            world_pos = obs.vis_pt_world_pos(int((u + 0.5) * block), int((v + 0.5) * block))
            point_vec = compute_unit_vector(world_pos - obs.pos)
            de = np.min(obs.depth[int(v * block) : int((v + 1) * block),
                                  int(u * block): int((u + 1) * block)])
            if de < safe_depth:
                continue

            dm = min(de * (DEPTH_MAX_M - DEPTH_MIN_M) + DEPTH_MIN_M, max_range)

            score = np.dot(v_mission, point_vec)
            if dm >= min(look_ahead_dist, max_range):
                score_grid[v, u] = score
            point_vec_data[v][u] = point_vec * dm

        # To get the (row, column) indices, use np.unravel_index
        max_flat_index = np.argmax(score_grid)
        row, col = np.unravel_index(max_flat_index, score_grid.shape)

        if not np.isinf(score_grid[row, col]):
            if score_grid[row, col] > 0:
                best_v = point_vec_data[row][col]
            else:
                best_v = np.array([0, 0, 0])
        else:
            v_avoid = self._calculate_repulsion(obs)
            best_v = limit_vector_scalar(v_mission + v_avoid, SPEED_LIMIT)
            sight_dir = self.tracker.transformer.rot_mat @ np.array([1, 0, 0])
            if np.dot(best_v, sight_dir) < 0:
                best_v = -obs.vel * 0.5
            print(f"Step: {self.step}. Use avoid vector. mission_v: {v_mission}, best_v: {best_v}\n")

        # we have an obstacle below, do now descend
        if best_v[2] + obs.alt < 0:
            best_v[2] = -max(obs.vel[2] * 0.8, 0)

        return best_v

    def _calculate_repulsion(self, obs: ObservationData, threshold=2.0):
        # 1. Focus on the central 'threat zone' of the depth map
        # Downsample for performance (e.g., take every 5th pixel)
        block = 6  # sample step
        score_grid = cv2.resize(obs.depth, (obs.res // block, obs.res // block), interpolation=cv2.INTER_AREA)

        v_avoid = np.array([0.0, 0.0, 0.0])

        # 2. Iterate through depth points
        # (u, v) are pixel coords, d is distance
        for (v, u), d in np.ndenumerate(score_grid):
            dm = d * (DEPTH_MAX_M - DEPTH_MIN_M) + DEPTH_MIN_M
            if dm >= threshold:  # Ignore noise and far-off objects
                continue
            # Convert pixel + depth to a Body-Frame vector (x, y, z)
            # This depends on your camera intrinsics
            world_pos = obs.vis_pt_world_pos(u * block, v * block)
            point_vector = world_pos - obs.pos

            # Push direction is the opposite of the point vector
            push_dir = compute_unit_vector(-point_vector)

            # Strength increases as distance d decreases
            strength = (threshold / dm) - 1.0

            v_avoid += push_dir * strength

        return v_avoid


class DroneAgentV2(DroneAgentMixin):
    def __init__(
        self,
        env: Any | None = None,
        landing_model_path: str | None = None,
        verbose: bool = False,
        **hyperparams: Any
    ):
        """
        Initialize the DroneAgent.

        Args:
            env: The gymnasium environment.
            model_path: Path to a pre-trained model.
            **hyperparams: Hyperparameters for the PPO model.
        """
        self.landing_model_path = landing_model_path
        self.env = env
        self.verbose = verbose

        # Radar
        self.transformer = DroneWorldTransformer()
        self.mapper = DroneWorldMapper()
        self.tracker = DroneLandingPadTracker(self.landing_model_path, self.mapper, self.transformer, dt=SIM_DT * CTRL_STEPS)
        self.navi = FlightNavigationAgent(self.mapper, self.tracker)
        self.governor = AeroInertiaGovernor(max_tilt_rad=MAX_TILT_RAD, max_speed_limit=SPEED_LIMIT)

        self.reset()

    def predict(self, observation: Dict, deterministic=True) -> Any:
        """
        Predict the next action based on the observation.

        Args:
            observation: The observation from the environment.

        Returns:
            The predicted action.
        """
        # decompose observation
        obs = ObservationData(observation=observation, transformer=self.transformer)

        # check if this is the beginning of a new flight task
        if not self._started:
            self._started = True
            self._start_position = obs.pos
            self.mapper.start(obs.search_center, obs.pos)
            self.navi.start(obs)

        self.transformer.set_drone_stance(obs.pos, obs.rpy)

        # should activate visual agent
        if self._step % CTRL_STEPS == 0:
            self.run_vis_agent(obs)

        flight_dir, yaw, max_speed = self.run_nav_agent(obs, vis_obs=self._vis_obs)
        if self.env is not None and self._step % CTRL_STEPS == 0:
            self._draw_debug(obs=obs, flight_dir=flight_dir)

        # Command generation from flight direction
        action = self.run_cmd_agent(flight_dir,
                                    yaw,
                                    max_speed=max_speed,
                                    obs=obs)

        self._step += 1
        return np.array([action])

    def run_vis_agent(self, obs: ObservationData):
        if not self.navi.needs_vis_agent(obs):
            self._debug_drone_sight(obs=obs)
            return

        self._vis_obs = obs

        # construct point cloud
        world_pos_map = obs.vis_to_world()

        mask = obs.depth_norm < 0.95

        # hit points
        point_cloud = world_pos_map[mask, :3].reshape(-1, 3)
        if len(point_cloud) > 0:
            self.mapper.insert_point_cloud(point_cloud, obs.pos, max_range=20)

        detect_box = None

        # Depth image based landing platform detection
        detect_box, goal_position, goal_vel = self.tracker.process_frame(obs, self._step)
        if detect_box[4] >= 0.5 and goal_position is not None:
            if self.env is not None:
                # actual_goal_pos, _ = p.getBasePositionAndOrientation(self.env._end_platform_uids[0], physicsClientId=self.env.CLIENT)
                # actual_goal_pos = np.array([actual_goal_pos[0], actual_goal_pos[1], actual_goal_pos[2] + 0.1])
                print(f"Step: {self._step}. Predicted goal position: {goal_position}, "
                      f"velocity: {goal_vel}, "
                      f"confidence: {self.tracker.confidence}, "
                      f"detected: {self.tracker.detected}\n")
            self._landing_detected_step = self._step
            obs.mask_detect_box(detect_box)

        self.detect_box = detect_box
        self._debug_drone_sight(obs=obs, detect_box=detect_box)

    def run_nav_agent(self, obs: ObservationData, vis_obs: ObservationData):
        # decompose observation
        v_flight, yaw = self.navi.get_next_target(obs=obs, detect_box=self.detect_box, step=self._step, vis_obs=vis_obs)
        max_speed = max(np.linalg.norm(v_flight), 0.3)
        flight_dir = compute_unit_vector(v_flight)

        return flight_dir, yaw, max_speed

    def reset(self):
        """
        Resets the agent's internal state. Called at the beginning of an episode.
        For this stateless PPO agent, this method can be empty.
        """
        self._started = False
        self._step = 0
        self._start_position = None
        self._landing_detected_step = None
        self._vis_obs = None
        self.detect_box = np.zeros(5)
        # Radar
        self.mapper.reset()
        self.tracker.reset()
        self.navi.reset()

    def save(self, path: str):
        pass

    def load(self, path: str):
        pass

    def run_cmd_agent(self, flight_dir, target_yaw, max_speed, obs: ObservationData):
        v_wind = np.zeros(3)
        max_tilt = MAX_TILT_RAD * (max_speed / SPEED_LIMIT)

        self.governor.max_tilt_rad = max_tilt
        cmd = self.governor.get_next_command(flight_dir, obs, v_wind,
                                                desired_max_speed=max_speed)
        target_v = cmd["target_velocity"]
        target_v_unit = cmd["v_unit"]
        target_speed = max(np.linalg.norm(target_v), 0.3)
        target_thrust = np.clip(target_speed / SPEED_LIMIT, 0, 1)

        action = np.hstack([
            target_v_unit,
            [
                target_thrust,
                np.clip(target_yaw / np.pi, -1, 1)
            ]
        ])
        return action

class DroneFlightController:
    def __init__(self):
        # Load your model (SB3, PyTorch, ONNX, etc.)
        self.model = DroneAgentV2(landing_model_path="best_model.pth")

    def act(self, observation):
        # observation: dict with "depth" (128,128,1) and "state" (N,)
        # Return action array [dir_x, dir_y, dir_z, speed, yaw]
        action, _ = self.model.predict(observation, deterministic=True)
        return action[0]

    def reset(self):
        # Reset internal state between missions
        self.model.reset()
